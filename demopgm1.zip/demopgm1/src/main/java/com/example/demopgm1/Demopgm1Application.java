package com.example.demopgm1;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class Demopgm1Application {
public static void main(String[] args) {
SpringApplication.run(Demopgm1Application.class, args);
}
}