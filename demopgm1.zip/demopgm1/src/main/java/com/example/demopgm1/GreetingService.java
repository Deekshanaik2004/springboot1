package com.example.demopgm1;

public interface GreetingService {
String greet();
}